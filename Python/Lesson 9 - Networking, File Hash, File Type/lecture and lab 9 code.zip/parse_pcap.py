# parse_pcap.py
# script to parse a pcap file
# Adapted from:
# https://jon.oberheide.org/blog/2008/10/15/dpkt-tutorial-2-parsing-a-pcap-file/)
# Oct 2017  Gaye Cleary Updated for 3.6 & added functionality

# For documentation on dpkt library, see....
# https://dpkt.readthedocs.io/en/latest/

import dpkt


def main():
    pcapfile = 'filtered2.pcap'
    f = open(pcapfile, 'rb')
    pcap = dpkt.pcap.Reader(f)

    for ts, buf in pcap:
        eth = dpkt.ethernet.Ethernet(buf)
        print(f'#<INFO> ethernet packet: {repr(eth)}')

        ip = eth.data
        print(f'#<INFO> ethernet packet: {repr(ip)}')
        # tcp = ip.data
        # print(f'#<INFO> ethernet packet: {repr(tcp)}')

        # print(f'{ip.src}:{tcp.sport} -> {ip.dst}:{tcp.dport}')

        break

    f.close()


# Standard boilerplate code to call the main() function to begin
# the program if run as a script.
if __name__ == '__main__':
    main()

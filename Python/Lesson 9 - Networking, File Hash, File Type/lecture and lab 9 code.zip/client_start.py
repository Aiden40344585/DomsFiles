# client.py
# start script to create send message to a listening server socket
# Owen Lo Nov 2016
# Change Log:
# Oct 2017  Gaye Cleary Updated for 3.6 & expanded

# For documentation on socket library, see....
# https://docs.python.org/3/library/socket.html
import socket
import sys

BUFFER_SIZE = 1024 #Packet size.

def client_socket(tcp_ip, tcp_port, message):

    # enter your code here to....
    # 1) create a local socket and
    # 2) connect it to the server socket
    pass
    pass
    print (f'#<INFO> Connected to server {tcp_ip}, {tcp_port}')

     
    # enter your code here to....
    # 3) send the message to the server and
    # 4) receive and decode the server's reply
    pass
    decoded_data = ''
    print('#<INFO> Reply Received:', decoded_data)
                
    # enter your code here to....
    # 5) close the socket
    pass

def main():

    message = input ('Enter a message to send to the server: ')

    tcp_ip = '127.0.0.1'
    tcp_port = '5005'
    client_socket(tcp_ip, int(tcp_port), message)

    print('#<INFO> exitting...')


# Standard boilerplate code to call the main() function to begin
# the program if run as a script.
if __name__ == '__main__':
    main()

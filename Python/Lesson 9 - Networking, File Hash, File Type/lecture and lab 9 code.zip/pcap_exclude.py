# pcap_exclude.py
# pcap packet analysis script for lab 9
# (solution for an exercise from lab 8)
# adapted from: Violent Python Ch 4 (p130ff)
# Python3.6 update: Nov 2017
# PEP8 update: Nov 18

import dpkt
import socket


def printPcap(pcap, exclude):
    for (ts, buf) in pcap:
        try:
            eth = dpkt.ethernet.Ethernet(buf)
            ip = eth.data
            src = socket.inet_ntoa(ip.src)
            dst = socket.inet_ntoa(ip.dst)
            if src != exclude:
                print(f'[+] Src: {src} --> Dst: {dst}')
        except Exception:
            pass


def main():
    pcapFile = 'filtered3.pcap'
    excludesrc = '146.176.164.91'
    f = open(pcapFile, 'rb')
    pcap = dpkt.pcap.Reader(f)
    print(f'[*] analysing {pcapFile} for packets not source {excludesrc}')
    print('-------------------')
    printPcap(pcap, excludesrc)


if __name__ == '__main__':
    main()

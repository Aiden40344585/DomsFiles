# thread_example.py
# from http://www.saltycrane.com/blog/2008/09/simplistic-python-thread-example/
# demonstrates the creation of parallel threads in Python
# Nov 2016 - updated Python3.6 Nov 2017
# Nov 2018 PEP8
import time
from threading import Thread


def myfunc(i):
    print(f"sleeping 5 sec from thread {i}\n")
    time.sleep(5)
    print(f"finished sleeping from thread {i}\n")


for i in range(10):
    t = Thread(target=myfunc, args=(i,))
    t.start()

# Script: file_type_sig.py
# Desc:   Check file type signature against filename extension.
# Modifed: Nov 2018 (PEP8 compliance)
#
import sys
import os
import binascii

file_sigs = {b'\xFF\xD8\xFF': ('JPEG', 'jpg'), b'\x47\x49\x46': ('GIF', 'gif')}


def check_sig(filename):
    """checks the file type signature of the file passed in as arg,
    returning the type of file and correct extension in a tuple """

    # Read File
    # ... YOUR CODE ... open file, and read 3 bytes
    print('[*] check_sig() File:', filename, end=' ')
    # print('Hash Sig:', binascii.hexlify(file_sig))

    # Check for file type sig
    # ... YOUR CODE ... to check type not in dic

    # File Type Sig found, so get sig and ext from file_sigs dic
    # ... YOUR CODE ... to get tuple from dic

    # Check if Type matches valid file extension
    # ... YOUR CODE ...

    # Valid ext
    # ... YOUR CODE ...
    print('[+] Extension:', os.path.splitext(filename)[1], end=' ')
    # print('    Actual File type:', file_type)


def main():
    # temp testing url argument
    sys.argv.append(r'c:\temp\invalid.txt')

    # Check args
    if len(sys.argv) != 2:
        print('usage: file_sig filename')
        sys.exit(1)

    file_hashsig = check_sig(sys.argv[1])


if __name__ == '__main__':
    main()

# Script:  ls.py
# Desc:    List files and subdirectories of current directory.
# Modified: Oct 2017, Nov18 (PEP8)
#
import os

curdir = os.curdir  # dir to list files for

# print details for all objects in dir
files = os.listdir(curdir)
for filename in files:
    path = os.path.join(curdir, filename)
    print(os.path.abspath(path))

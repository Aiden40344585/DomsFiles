# Script:  ls_logfile.py
# Desc:    List files and subdirectories in current directory.
# this version writes to file
# goes with lab 07 - this includes answers for most of the questions
# Modified: Oct 2017
#
import os
import datetime

try:
    # dir to list files for
    # curdir = os.curdir
    curdir = r'C:\Program Files\Python37'
    logfile = open(r'c:\temp\lslog.txt', 'w')  # open file for writing
    # find details for all files in dir
    files = os.listdir(curdir)
    for filename in files:
        path = os.path.join(curdir, filename)
        time = datetime.datetime.fromtimestamp(os.path.getctime(path))
        time = str(time).split('.')[0]  # get rid of milliseconds
        size = os.path.getsize(path)
        # print path
        if os.path.isfile(path):
            logfile.write('- ')
        elif os.path.isdir(path):  # directory
            logfile.write('d ')
        logfile.write(f'{size:8d} {time} {os.path.abspath(path)}\n')

    # print dir summary
    logfile.write(f'\t  {len(files)} Files and Directories')
except IOError as err:
    print(f'File Error: {IOError}')
finally:
    if 'logfile' in locals():
        logfile.close()

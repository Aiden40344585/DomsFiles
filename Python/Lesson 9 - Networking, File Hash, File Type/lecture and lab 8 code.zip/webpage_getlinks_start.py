# Script:   webpage_getlinks.py
# Desc:     Basic web site info gathering and analysis script.
#           From a URL gets page content, and parses out hyperlinks.
# Modified: Oct 2017
# Nov18 (PEP8)
import sys
import re
import webpage_get


def print_links(page):
    ''' find all hyperlinks on the webpage input and print '''
    print('[*] print_links()')
    # regex to match on hyperlinks
    links = re.findall(r'\<a.*href\=.*http\:.+', page.decode())
    # sort and print the links
    links.sort()
    print(f'[+] {len(links)} HyperLinks Found:')
    for link in links:
        print(link)


def main():
    # temp testing url argument
    sys.argv.append(r'http://www.napier.ac.uk')

    # Check args
    if len(sys.argv) != 2:
        print('[-] Usage: webpage_getlinks URL')
        return

    # Get the web page
    page = webpage_get.wget(sys.argv[1])
    # Get the links
    print_links(page)


if __name__ == '__main__':
    main()

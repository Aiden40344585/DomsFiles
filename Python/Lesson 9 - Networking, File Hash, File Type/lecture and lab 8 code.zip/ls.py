# Script:  ls.py
# Desc:    List files and subdirectories in current directory.
# goes with lab 09 - this includes answers for most of the questions
# Modified: Nov 2018 (PEP8)
#
import os
import datetime

# dir to list files for
# curdir = os.curdir
curdir = r'C:\Program Files\Python37'

# print details for all files in dir
files = os.listdir(curdir)
for filename in files:
    path = os.path.join(curdir, filename)
    time = datetime.datetime.fromtimestamp(os.path.getctime(path))
    time = str(time).split('.')[0]  # get rid of milliseconds
    size = os.path.getsize(path)
    # print path
    if os.path.isfile(path):
        print('- ', end='')
    elif os.path.isdir(path):  # directory
        print('d ', end='')
    print(f'{size:8d} {time} {os.path.abspath(path)}')

# print dir summary
print(f'\t  {len(files)} Files and Directories')

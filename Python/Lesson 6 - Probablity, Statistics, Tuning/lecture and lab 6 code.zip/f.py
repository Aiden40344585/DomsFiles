# modified from from https://legacy.python.org/doc/essays/list2str
# Python Patterns - An Optimization Anecdote (which was written for Python 2.x)
# file f.py
# PL October 2018
# 
import time

def timing(f, n, a):
    print (f.__name__, end=': ')
    r = range(n)
    t1 = time.perf_counter_ns() #or time.time_ns or time.process_time_ns
    for i in r:
        f(a); f(a); f(a); f(a); f(a); f(a); f(a); f(a); f(a); f(a)
    t2 = time.perf_counter_ns() 
    print (round(t2-t1, 3))

def f1(list):
    string = ""
    for item in list:
        string = string + chr(item)
    return string

def f2(list):
    '''my own function using list comprehension
       trying to make this more efficient by making string a list but keep getting errors
       seems to work when testing bits though'''
    string = ''
    #print(f'value: {string}, type: {type(string)}')
    newstring = [string+(chr(item)) for item in list]
    #print(f'newstring: {newstring}')
    return ''.join(newstring)

'''def f2(list):
    return reduce(lambda string, item: string + chr(item), list, "")'''

def f3(list):
    string = ""
    for character in map(chr, list):
        string = string + character
    return string

def f4(list):
    string = ""
    lchr = chr
    for item in list:
        string = string + lchr(item)
    return string

def f5(list):
    string = ""
    for i in range(0, 256, 16): # 0, 16, 32, 48, 64, ...
        s = ""
        for character in map(chr, list[i:i+16]):
            s = s + character
        string = string + s
    return string

'''import string
def f6(list):
    return string.joinfields(map(chr, list), "")'''

import array, binascii
def f7(list):
    #return array.array('B', list).tobytes()
    return array.array('B', list).tobytes().decode('latin-1') #need something for 256 bytes known as windows-1252

testdata = range(256)
print ('testdata')
testfuncs = f1, f2, f3, f4, f5,  f7
for f in testfuncs: print (f.__name__, f(testdata)) #confirm all functions return same
for f in testfuncs: timing(f, 1000, testdata)

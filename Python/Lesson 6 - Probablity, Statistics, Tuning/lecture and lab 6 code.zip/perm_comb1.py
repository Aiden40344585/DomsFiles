# Permutations and Combinations using Python
# Petra Oct 2018

import itertools
from scipy.special import comb,perm #py -m pip install scipy from cmd line

# relay team
runners = ['Black','Thant','Farah','Jones','Bolt','Thompson']
teamsize=4
number_of_possible_teams = perm(len(runners),teamsize, exact=True) #P(6,4)

possible_teams = itertools.permutations(runners,teamsize)
print(f'There are {number_of_possible_teams} possible teams of {teamsize}:')
for t in possible_teams:
    print(t)


# football tournament
participants=['ManU','Real','Juventus','Bayern','Ajax','Barcelona','Liverpool','Schalke']
print('Round-Robin: Every team plays every other team.',end=' ')
print(f'{comb(len(participants),2,exact=True)} matches to be scheduled:') #C(8,2)
matches=itertools.combinations(participants,2)
for m in matches:
    print(f'{m[0]:10} v {m[1]}')

# timing_test1.py
# modified from
# https://marcobonzanini.com/2015/01/05/my-python-code-is-slow-tips-for-profiling/
# time 4 different ways of adding the integers from 1 to N

def loopy(N=1000000):
    total = 0
    for i in range(N+1):
        total += i
    return total

def listy(N=1000000):
    mylist = [i for i in range (N+1)]
    total = sum(mylist)
    return total
 
def pythonic(N=1000000):
    total = sum(range(N+1))
    return total

def mathematical(N=1000000):
    total = N*(N+1)//2
    return total

if __name__ == '__main__':
    import time
    N = 10000 # 20#1000000
    print(f"adding up ints from 1 to {N}")
    t0 = time.time()
    result = loopy(N)
    t1 = time.time()
    print(f"loopy():\t {t1 - t0:.9f} (result: {result})")
    t0 = time.time()
    result = listy(N)
    t1 = time.time()
    print(f"listy():\t {t1 - t0:.9f} (result: {result})")
    t0 = time.time()
    result = pythonic(N)
    t1 = time.time()
    print(f"pythonic():\t {t1 - t0:.9f} (result: {result})")
    t0 = time.time()
    result = mathematical(N)
    t1 = time.time()
    print(f"mathematical():\t {t1 - t0:.9f} (result: {result})")

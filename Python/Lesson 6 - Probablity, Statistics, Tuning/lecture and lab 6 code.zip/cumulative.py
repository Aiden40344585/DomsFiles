# cumulative probability
# Petra Oct 2018

from scipy.special import comb #py -m pip install scipy from cmd line

def n_trials_exact(p,r,n):
    '''calculate the probability of exactly r successes in n trials
    where p is the probability of success in one trial
    using the formula C(n,r) * p**r * (1-p)**(n-r)'''
    prob=comb(n,r)*(p**r)*((1-p)**(n-r))
    return prob

def cumulative(p,upto,n):
    '''calculate cumulative probability of upto successes in n trials
    where p is the probability of success in one trial'''
    cum=0
    for i in range(upto+1):
        cum+=n_trials_exact(p,i,n)
    return cum

def spares():
    '''calculate the number of spares needed so that the probability
    of running out is less than "out"'''
    return None
    
#test cases 
print(n_trials_exact(1/500,4,500))
print(cumulative(1/500,3,500))







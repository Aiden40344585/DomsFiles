import hashlib

def allPerms(A,B,C):
    z=[(a,b,c) for a in A for b in B for c in C]
    yield z

for triple in allPerms(["big","small"],
                       ["red","green","blue"],
                       ["circle","triangle","square"]):
  for i in triple:
    phrase= f'{i[0]} {i[1]} {i[2]}'
    m=hashlib.md5(phrase.encode('utf-8')).hexdigest()
    if m.startswith('4b23'):
      print(phrase)

# spellcheck_prepare.py
# reads a file (typically a novel) and prepares it:
# result is a simple list of words,
# with newlines, other "unusual" characters and one-letter words stripped out
# writes result to a file (which requires newlines be added in again)
# based on https://stackoverflow.com/questions/1059559/split-strings-with-multiple-delimiters
import re

infile = "frankenstein.txt" # file to be processed
outfile = 'clean.txt' # for storing processed text

print(f'pre-processing {infile} and writing results to {outfile}')

text = open(infile, encoding="utf8")
content=text.read().lower()
words0=re.split('\W+', content)

words = []
for x in words0:
    if len(x)>=2: words.append(x)

print(f'words is type {type(words)} and contains {len(words)} words')
print(f'The first 100 words are: {words[:100]}')

#frank_processed
out = open(outfile, mode='w')
for x in words:
    out.write(x+'\n')
out.close()

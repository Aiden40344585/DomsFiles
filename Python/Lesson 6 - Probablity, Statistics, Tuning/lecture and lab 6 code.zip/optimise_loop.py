#loop optimisation by moving dots to variables
# modified from https://dzone.com/articles/6-python-performance-tips

# function1 should be faster than function2
# as it evaluates str.upper and upperlist.append methods only once
def function1(lowerlist, upperlist=[]):
    upper = str.upper
    append = upperlist.append
    for word in lowerlist:
        append(upper(word))
    return(upperlist)


#function2 should be slower as it evaluates methods in every iteration
def function2(lowerlist, upperlist=[]):
    for word in lowerlist:
        upperlist.append(str.upper(word))
    return(upperlist)

#function3 uses list comprehension instead of a loop
def function3(lowerlist):
    upper = str.upper
    upperlist = [upper(word) for word in lowerlist]
    return(upperlist)


# now run the functions for comparison
lowerlist = ['this', 'is', 'lowercase']*1000000
upperlist1 = function1(lowerlist,[])
upperlist2 = function2(lowerlist,[])
upperlist3 = function3(lowerlist)
if upperlist1==upperlist2==upperlist3:
    print('all results are identical')
else:
    print('not all results the same')


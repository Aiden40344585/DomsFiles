# spellcheck.py
# a possible solution for lab 4 case study, distributed with lab 6
# assumes the source has been pre-processed with spellcheck_prepare.py.
# Petra October 2018

def linS(target, words):
    '''linear search for target in words. words need not be sorted'''
    for s in words:
        if s==target:
            return True
    return False

def binS(target, words):
    '''binary search for target in words. words must be a sorted list.'''
    def chop(lo,hi):
        if (lo>=hi):
            return False
        mid = (lo+hi) // 2
        piv = words[mid]
        if piv==target:
            return True
        if piv<target:
            return chop(mid+1,hi)
        return chop(lo,mid)
    return chop(0,len(words))

def hashS(target, words):
    '''hash table search for target in words. words should be a dictionary'''
    if target in words:
        return True
    return False

def main():
    #Get a list of words
    ### extend this to read in all three "dictionaries"
    words = [s.strip("\n").lower() for s in open("words.txt")] 
    words.sort() # sort the list
    wordshash = {word:None for word in words} #hash search needs a dictionary
    # read the target
    target = [s.strip("\n").lower() for s in open("clean.txt")]
    target = target[:1000] # selects first x words for faster runtimes - comment out to run with whole novel
    bincounter = lincounter = hashcounter = 0
    print('working...please be patient')
    for w in target:
        if not linS(w,words):
            lincounter+=1
    print('linear search completed.')
    for w in target:
        if not binS(w,words):
            bincounter+=1
    print('binary search completed.')
    for w in target:
        if not hashS(w,wordshash):
            hashcounter+=1
    print('hashsearch completed.')
    if lincounter == bincounter == hashcounter:
        print(f'{lincounter} non-matched words, same for all algorithms')
    else:
        print(f'linear, binary and hash searches returned {lincounter}, {bincounter}, {hashcounter} non-matched words')
        print('INVESTIGATE WHY NOT EQUAL')

if __name__ == '__main__':
    main()

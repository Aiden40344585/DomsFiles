# permutations1.py
# used for lecture 6
# compares getting all possible permutations with a list and a generator
# sampling with replacement
# updated Oct 2018

def allPerm(A,B,C):
    """Generator for all possible permutations of A,B,C from loop"""
    for a in A:
        for b in B:
            for c in C:
                yield (a,b,c)

def allPerm_list(A,B,C):
    """List of all possible permutations of A,B,C from loop"""
    lis=[]
    for a in A:
        for b in B:
          for c in C:
            lis.append((a,b,c))
    return lis

def allPerm_gencomp(A,B,C):
    """Generator for all possible permutations of A,B,C from list comprehension"""
    z=[(a,b,c) for a in A for b in B for c in C]
    yield z

def allPerm_comp(A,B,C):
    """List of all possible permutations of A,B,C from list comprehension"""
    z=[(a,b,c) for a in A for b in B for c in C]
    return z

def main():
    A,B,C = ["big","small"],["red","green","blue"],["circle","triangle","square"] 
    y = allPerm_comp(A,B,C)
    print(f'**USING RETURN**\ny = {y}\n')
    print(f'len(y) = {len(y)}\n')
    x = allPerm_gencomp(A,B,C)
    print(f'**USING YIELD**\nx = {x}\nx = ', end='')
    for triple in x: print(triple)
    print(f'len(x) = {len(x)}')

if __name__ == '__main__':
    main()


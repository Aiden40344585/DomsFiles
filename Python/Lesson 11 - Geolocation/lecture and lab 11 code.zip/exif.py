# exif processor that uses named markers
# Petra Leimich (last modified Nov 2018)
# NOT PEP8 compliant and could be simplified e.g. with f-strings
#
# uses info from:
# https://www.blog.pythonlibrary.org/2010/03/28/getting-photo-metadata-exif-using-python/
# http://bogdan.org.ua/2007/08/12/python-iterate-and-read-all-files-in-a-directory-folder.html
# date time conversion: http://www.litster.org/blog/2010/05/30/python-and-exif-metadata-theres-more-than-one-way-to-do-it/
# open browser http://stackoverflow.com/questions/22445217/python-webbrowser-open-to-open-chrome-browser

from PIL import Image  # use pip install pillow to get PIL
from PIL.ExifTags import TAGS
import os
from datetime import datetime, date, time
import webbrowser

# specify necessary API key and paths
chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'  # Path for chrome.exe
path = 'pics'  # relative or absolute path of directory containing the photos to be used
API_Key = ''  # Add the API Key here (see moodle, or create your own)


def get_exif(fn):
    ret = {}
    i = Image.open(fn)
    info = i._getexif()
    for tag, value in info.items():
        decoded = TAGS.get(tag, tag)
        ret[decoded] = value
    return ret


url=f'https://maps.googleapis.com/maps/api/staticmap?key={API_Key}&autoscale=2&size=640x640&maptype=roadmap&format=png&visual_refresh=true'
geo_found=0 # counts pics with GPS info - this is added to the URL
geo_not_found=0 # counts pics without GPS info

files=os.listdir(path)
print(files)

for pic in files:
    try:     # get exif data
        exif_dict=get_exif(path+'\\'+pic)
        print_make = '%s (%s) with %s'  % (exif_dict['Make'], exif_dict['Model'], exif_dict['Software'])
        rawdate=exif_dict['DateTimeOriginal']
        exif_date, exif_time  = rawdate.split(' ')
        (y, mm, d) = exif_date.split(':')
        da=date(int(y), int(mm), int(d))
        (h, min, s) = exif_time.split(':')
        tm=time(int(h), int(min), int(s))
        dt=datetime.combine(da, tm)
        print_created = dt.strftime("%A, %d. %B %Y at %H:%M")

        try:
            # compile latitude and longitude from exif info. unicode value is for degree sign
            lat_deg=exif_dict['GPSInfo'][2][0][0]/float(exif_dict['GPSInfo'][2][0][1])
            lat_min=exif_dict['GPSInfo'][2][1][0]/(float(exif_dict['GPSInfo'][2][1][1]))
            lat_sec=exif_dict['GPSInfo'][2][2][0]/(float(exif_dict['GPSInfo'][2][2][1]))
            latstr=str(int(lat_deg))+u"\u00b0 "+str(int(lat_min))+"' "+str(int(lat_sec))+'" '+exif_dict['GPSInfo'][1]
            lon_deg=exif_dict['GPSInfo'][4][0][0]/float(exif_dict['GPSInfo'][4][0][1])
            lon_min=exif_dict['GPSInfo'][4][1][0]/(float(exif_dict['GPSInfo'][4][1][1]))
            lon_sec=exif_dict['GPSInfo'][4][2][0]/(float(exif_dict['GPSInfo'][4][2][1]))
            lonstr=str(int(lon_deg))+u"\u00b0 "+str(int(lon_min))+"' "+str(int(lon_sec))+'" '+exif_dict['GPSInfo'][3]
            # calculate latitude in decimal notation
            lat= lat_deg+lat_min/60+lat_sec/3600
            if exif_dict['GPSInfo'][1]=='S':
                lat = - lat
            # calculate longitude in decimal notation
            lon= lon_deg+lon_min/60+lon_sec/3600
            if exif_dict['GPSInfo'][3]=='W':
                lon = - lon
            if lat_min<60 and lat_sec<60 and lon_min<60 and lon_sec<60:
                print_deg = "Location (degrees): %s, %s" % (latstr, lonstr)
            print_dec ="Location (decimal): (%f, %f)" % (lat, lon)
            geo_found+=1
            url=url+'&markers=label:%d%%7C%f, %f' % (geo_found, lat, lon)
            print("[%d] %s" % (geo_found, pic))
            print(print_make)
            print(print_created)
            print(print_deg)
            print(print_dec)
        except:
            print("[-] ", pic)
            print(print_make)
            print(print_created)
            print("No GPS data found")
            geo_not_found+=1
    except:
        print("[-] ", pic)
        print("no EXIF data found")
    print("====================")
print("[%d] Found %d photos with GPS location" % (geo_found, geo_found))
print("[-] Found %d photos without GPS location" % (geo_not_found))
if geo_found:
    print("[+] This URL maps the locations of the photos with GPS information")
    print("    should open automatically, if not, copy and paste URL into browser")
    print(url)
    webbrowser.get(chrome_path).open(url)
else:
    print("None of the photos contained geo-location. Nothing to map")



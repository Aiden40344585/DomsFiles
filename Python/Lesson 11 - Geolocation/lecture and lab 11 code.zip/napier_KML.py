# napier_KML.py
# simple example to show creation of KML file with one point
# Petra 13/11/16
# last updated Nov 2018 (PEP8)

import simplekml

# define KML object
kml = simplekml.Kml()
# add a single Point
pnt = kml.newpoint(name="ENU",
                   coords=[(-3.2136, 55.932892)],
                   description="Merchiston Campus")
kml.save("napier.kml")  # save
print(kml.kml())  # print kml to screen

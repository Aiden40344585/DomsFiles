# experimenting generating large random list
# for sorting, we need the list itself, we can't generate one value at a time
import random
import time
import numpy

large=2000000
t0=time.time()
numbers = [random.randint(1,1000) for x in range(large)]
t1=time.time()
print(t1-t0)
numbers2=[]
for x in range(large):
    numbers2.append(random.randint(1,1000)) #pretty similar to above
t2=time.time()
print(t2-t1)
numbers3=numpy.random.randint(0,large*2,large)
t3=time.time()
print(t3-t2)

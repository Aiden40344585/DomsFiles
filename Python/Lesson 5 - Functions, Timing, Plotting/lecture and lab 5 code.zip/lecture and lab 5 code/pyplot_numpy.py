# Example Pyplot Three from https://matplotlib.org/gallery/index.html
import numpy as np   #(may need to pip install numpy)
import matplotlib.pyplot as plt #(may need to pip install matplotlib)

# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2) # range() only works with integer steps,
                           # np.arange() allows decimal steps
                           # and creates an "ndarray" not a list

# red circles, blue squares with line and green triangles
plt.plot(t, t, 'ro', t, t**2, 'bs-', t, t**3, 'g^')
plt.show()

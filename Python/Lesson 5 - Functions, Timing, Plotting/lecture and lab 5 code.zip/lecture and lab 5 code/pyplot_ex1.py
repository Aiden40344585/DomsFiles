# Example Pyplot Three from https://matplotlib.org/gallery/index.html

import matplotlib.pyplot as plt #(may need to pip install matplotlib)

# evenly sampled time at 200ms intervals
t = [i/5 for i in range(0,25)] 
t_sq=[i**2 for i in t]
t_cube=[i**3 for i in t]

# red, blue and green lines with legends
plt.plot(t, t, 'r', label='y=x linear')
plt.plot(t, t_sq, 'b', label='y=x^2 quadratic')
plt.plot(t, t_cube, 'g', label='y=x^3 cubed')
plt.legend() # needed to actually create the legend

plt.show()

# "Obvious" algorithm
def power(a,b,m):
	acc = 1
	counter=0
	for i in range(b):
		acc = acc * a
		counter+=1
	return acc % m, counter

# Some test runs
print (power(3,4,100))
print (power(2,10,1000))
# A prime according to
# https://primes.utm.edu/lists/small/millions/
#p = 941083987 # commented out as this will hang forever
p = 635389
# Fermat's Little Theorem says this will be 1
print (power(2,p-1,p))

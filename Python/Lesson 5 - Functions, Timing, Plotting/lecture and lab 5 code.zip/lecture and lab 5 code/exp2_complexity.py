# Smarter algorithm
def power(a,b,m):
	global counter
	if b==0:
		return 1
	sqrt = power(a,b//2,m)
	counter +=1
	if b % 2 == 0:
		return (sqrt*sqrt) % m
	else:
		return (a*sqrt*sqrt) % m

# Some test runs
counter=0
print (power(3,4,100), counter)
counter=0
print (power(2,10,1000), counter)
# A prime according to
# https://primes.utm.edu/lists/small/millions/
p = 941083987
# Fermat's Little Theorem says this will be 1
counter=0
print (power(2,p-1,p), counter)
